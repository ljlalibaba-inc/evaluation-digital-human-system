---
name: query-gen
description: Generate realistic search queries based on user personas for testing search/recommendation systems. Use when creating test queries, evaluating search quality across demographics, or benchmarking recommendation algorithms with diverse user behavior patterns.
---

# Query Generator Skill

基于数字人设自动生成真实搜索 Query，用于评测搜索推荐系统效果。

## 核心功能

- **8 种用户人设**: 覆盖宝妈、老人、Z 世代等不同群体
- **8 大生活场景**: 医疗、餐饮、教育、娱乐等
- **自然语言生成**: 根据人设特征生成符合真实表达习惯的 Query
- **评测友好**: 输出包含预期评测重点，便于自动化评测

## 快速开始

### Java 使用

**编译和运行:**

```bash
cd /Users/linjie/Documents/workspace/skill/query-gen/java

# 编译
javac QueryGenerator.java QueryGeneratorDemo.java

# 运行演示
java QueryGeneratorDemo
```

**代码示例:**

```java
// 1. 初始化
QueryGenerator generator = new QueryGenerator();

// 2. 生成单个 Query
GeneratedQuery query = generator.generateSingle("新手焦虑型妈妈", "医疗健康");
System.out.println(query.getQuery());  
// → "urgent 宝宝发烧 求推荐儿科医院附近靠谱的"

// 3. 批量生成
List<GeneratedQuery> queries = generator.generateBatch(
    "效率实用型妈妈", "餐饮外卖", 10
);

// 4. 多人群对比
Map<String, List<GeneratedQuery>> results = generator.generateMultiPersona(
    Arrays.asList("新手焦虑型妈妈", "谨慎保守型老人"),
    "医疗健康", 
    5
);

// 5. 获取所有人设/场景名称
Set<String> personas = generator.getAllPersonaNames();
Set<String> scenes = generator.getAllSceneNames();
```

### Python 使用

**运行演示:**

```bash
cd /Users/linjie/Documents/workspace/skill/query-gen/python

# 运行演示
python3 test_demo.py
```

**代码示例:**

```python
from query_generator import QueryGenerator

generator = QueryGenerator()

# 生成单个 Query
query = generator.generate_single("新手焦虑型妈妈", "医疗健康")
print(query.query)  # → "urgent 宝宝发烧 求推荐儿科医院"

# 批量生成
queries = generator.generate_batch("效率实用型妈妈", "餐饮外卖", count=10)

# 多人群对比
results = generator.generate_multi_persona(
    ["新手焦虑型妈妈", "谨慎保守型老人"],
    "医疗健康",
    count_per_persona=5
)
```

## 支持的人设

| 人设 ID | 人设名称 | 特征描述 | Query 风格 |
|--------|----------|----------|-----------|
| P001 | 新手焦虑型妈妈 | 0-1 岁宝宝，第一胎，谨慎焦虑 | 长句、多疑问、强调"靠谱/安全" |
| P002 | 效率实用型妈妈 | 职场妈妈，时间碎片化，追求效率 | 短句、关键词、强调"快/近" |
| P003 | 品质追求型妈妈 | 经济条件好，注重品质和体验 | 描述详细、强调"高端/专业" |
| P004 | 价格敏感型妈妈 | 精打细算，关注性价比 | 简洁直接、强调"便宜/优惠" |
| P005 | 社交分享型妈妈 | 爱新鲜事物，爱分享，跟风 | 求推荐、带情感词 |
| P006 | 谨慎保守型老人 | 60 岁+，数字素养低，害怕被骗 | 正式、强调"正规/有保障" |
| P007 | 求助依赖型老人 | 不熟悉操作，习惯求助 | 求助式、简单语言 |
| P008 | 潮流探索型 Z 世代 | 18-25 岁，追新潮，注重体验 | 短句、网络用语、潮流词 |

**注意**: 人设名称包含特殊字符"Z 世代"(无空格)，使用时请确保完全匹配。建议通过 `getAllPersonaNames()` 获取准确名称。

## 支持的场景

- **医疗健康**: 儿科医院、儿童医院、疫苗接种、体检、药店、推拿、急诊
- **餐饮外卖**: 儿童餐、营养餐、辅食、月子餐、亲子餐厅、外卖、快餐
- **教育早教**: 早教中心、托班、兴趣班、幼儿园、亲子活动、游泳、英语
- **生活服务**: 保洁、月嫂、育儿嫂、儿童摄影、维修、洗衣
- **休闲娱乐**: 儿童乐园、亲子游、游泳馆、绘本馆、亲子酒店、游乐场、动物园
- **社区服务**: 社区医院、老年食堂、便民超市、快递代收、理发、维修
- **便民生活**: 缴费、充值、查询、预约、办事、咨询
- **新潮服务**: 剧本杀、密室、VR、电竞、自拍馆、猫咖、潮玩

## 输出字段说明

```json
{
  "query": "生成的 Query 文本",
  "persona": "人设名称",
  "scene": "场景名称", 
  "intent": "用户意图",
  "complexity": "复杂度 (高/中/低)",
  "emotionLevel": "情感强度 (高/中/低)",
  "expectedFocus": ["评测重点 1", "评测重点 2"]
}
```

## 使用场景示例

### 场景 1: 搜索质量评测

```java
// 为不同人设生成测试 Query，评测搜索系统
String[] personas = {"新手焦虑型妈妈", "效率实用型妈妈", "谨慎保守型老人"};

for (String persona : personas) {
    List<GeneratedQuery> queries = generator.generateBatch(persona, "医疗健康", 20);
    
    for (GeneratedQuery q : queries) {
        SearchResult result = searchService.search(q.getQuery());
        
        // 根据 expectedFocus 自动评测
        for (String focus : q.getExpectedFocus()) {
            RelevanceScore score = evaluator.evaluate(result, focus);
            report.add(persona, focus, score);
        }
    }
}
```

### 场景 2: A/B 测试

```java
// 控制组 vs 实验组，使用相同 Query 集合
List<GeneratedQuery> testQueries = generator.generateBatch(
    "效率实用型妈妈", "餐饮外卖", 100
);

ABTestResult result = abTestRunner.run(
    () -> controlAlgorithm.search(testQueries),
    () -> experimentAlgorithm.search(testQueries)
);
```

### 场景 3: 覆盖率测试

```java
// 确保所有人设和场景组合都被覆盖
for (String persona : generator.getAllPersonaNames()) {
    for (String scene : generator.getAllSceneNames()) {
        List<GeneratedQuery> queries = generator.generateBatch(persona, scene, 5);
        coverageTest.add(persona, scene, queries);
    }
}
```

## 文件结构

```
/Users/linjie/Documents/workspace/skill/query-gen/
├── SKILL.md                 # 技能文档
├── java/
│   ├── QueryGenerator.java  # Java 实现 (单文件)
│   └── QueryGeneratorDemo.java  # 演示程序
└── python/
    ├── query_generator.py   # Python 实现
    └── test_demo.py         # 演示程序
```

## 依赖

**Java**:
- 无外部依赖，标准库即可运行

**Python**:
- 无外部依赖，标准库即可 (Python 3.7+)

## 注意事项

1. **Unicode 编码**: 人设名称"潮流探索型 Z 世代"中的"Z 世代"没有空格，使用时请确保完全匹配
2. **推荐使用 API**: 建议通过 `getAllPersonaNames()` 和 `getAllSceneNames()` 获取准确的名称列表
3. **独立版本**: Java 和 Python 实现都是独立的，不依赖任何外部项目

## License

MIT License
